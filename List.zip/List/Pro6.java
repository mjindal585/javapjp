import java.util.Vector;

public class Pro6 {
	

	public static void main(String[] args) {
        Vector<String> newList = new Vector<String>();
        
        newList.add("Jan");
        newList.add("Feb");
        newList.add("Mar");
        newList.add("Apr");
        newList.add("May");
        newList.add("JUn");
        newList.add("Jul");
        newList.add("Aug");
        newList.add("Sep");
        newList.add("Oct");
        newList.add("Nov");
        newList.add("Dec");

		
		
		System.out.println("Months are : " + newList);
		


	}

}